// ── PATCH: tailwind.config.ts (merge into existing `theme.extend`) ────────────
//
// Add inside theme.extend:
//
// borderRadius: {
//   '3xl': '1.5rem',   // bento cards inner radius
//   '4xl': '2rem',     // bento cards outer radius
// },
//
// boxShadow: {
//   'bento': '0 4px 20px -2px rgba(45, 34, 24, 0.05)',
//   'bento-hover': '0 8px 30px -4px rgba(45, 34, 24, 0.10)',
//   'gold': '0 4px 20px rgba(196, 169, 125, 0.25)',
// },
//
// colors: {
//   cream:   '#F5F0E8',
//   espresso:'#2D2218',
//   gold:    '#C4A97D',
//   'gold-light': '#D4C0A1',
// },
//
// ─── scrollbar-hide utility (add to plugins array): ───────────────────────────
//
// plugin(({ addUtilities }) => {
//   addUtilities({
//     '.scrollbar-hide': {
//       '-ms-overflow-style': 'none',
//       'scrollbar-width': 'none',
//       '&::-webkit-scrollbar': { display: 'none' },
//     },
//   });
// }),
//
// ─────────────────────────────────────────────────────────────────────────────
